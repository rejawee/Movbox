
import '../models/movie.dart';

final List<Movie> movies = [
  Movie(
    title: "Live Channel 1",
    thumbnail: "https://i.imgur.com/xyz123.jpg",
    description: "Watch live stream via M3U.",
    streamUrl: "http://darkteam.vip/80/get.php?username=17276473060173&password=31627764887528&type=m3u",
  ),
];
